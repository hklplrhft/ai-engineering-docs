# AI Engineering Starter Kit

Het 5-lagensysteem uit de AI Engineering Gids, klaar om te gebruiken.

## Wat zit erin?

```
global/
  CLAUDE.md              --> Kopieer naar ~/.claude/CLAUDE.md
                             Geldt voor AL je projecten (Laag 1)

project/
  CLAUDE.md              --> Kopieer naar je project root (Laag 2)
                             Pas aan voor jouw project
  .claude/
    settings.json        --> Hooks: lint, typecheck, tests (Laag 5)
    skills/
      start-feature/     --> /start-feature skill (Laag 5)
      fix-bug/           --> /fix-bug skill (Laag 5)
  docs/
    refs/                --> Taakspecifieke regels (Laag 3)
      database-regels.md
      api-regels.md
      build-regels.md
  .gitignore-toevoegen   --> Regels om toe te voegen aan je .gitignore
```

## Installatie

### 1. Globale regels (eenmalig)
```bash
mkdir -p ~/.claude
cp global/CLAUDE.md ~/.claude/CLAUDE.md
# Pas aan naar jouw voorkeuren
```

### 2. Project setup (per project)
```bash
cd mijn-project

# Kopieer project bestanden
cp -r project/CLAUDE.md .
cp -r project/.claude .
cp -r project/docs .

# Pas CLAUDE.md aan voor jouw project
# Pas .claude/settings.json aan voor jouw test/lint commando's

# Voeg .gitignore regels toe
cat project/.gitignore-toevoegen >> .gitignore
```

### 3. Laag 4: Geheugen
Laag 4 (persistent geheugen) wordt automatisch aangemaakt door Claude Code.
- Auto memory: Claude leert vanzelf tijdens het werken
- Handmatig: gebruik /memory om regels en beslissingen op te slaan

## De 5 lagen

| Laag | Wat                    | Waar                    | Type          |
|------|------------------------|-------------------------|---------------|
| 1    | Globale regels         | ~/.claude/CLAUDE.md     | Altijd geladen |
| 2    | Projectregels          | ./CLAUDE.md             | Altijd geladen |
| 3    | Taakspecifieke regels  | docs/refs/*.md          | Op aanvraag   |
| 4    | Persistent geheugen    | MEMORY.md + auto memory | Automatisch   |
| 5    | Uitvoerbare extensies  | skills, agents, hooks   | Actief        |

## Eerste gebruik

```bash
cd mijn-project
claude
# Verken: "Geef me een overzicht van dit project"
# Feature: /start-feature login pagina met e-mail
# Bug: /fix-bug users krijgen 500 bij inloggen
```

Meer info: zie de AI Engineering Gids.
