# Mijn Project

## Overview
<!-- Beschrijf je project in 1-2 zinnen -->
Webshop gebouwd met Next.js 14, Prisma ORM, PostgreSQL.

## Tech stack
- Frontend: React + Tailwind CSS
- Backend: Next.js API routes
- Database: PostgreSQL via Prisma
- Tests: Jest + React Testing Library

## Kritieke regels
- ALTIJD Prisma migrate gebruiken, nooit raw SQL voor schema changes
- Componenten in src/components/, pages in src/app/
- Zie docs/refs/api-regels.md voor API conventies
- Zie docs/refs/database-regels.md voor database valkuilen

## Commando's
- Test: npm test
- Lint: npm run lint
- Build: npm run build
- Dev: npm run dev
