# Database regels
# Voeg hier regels toe die Claude moet kennen bij database-werk.
# Elke fout die Claude maakt wordt een regel -- zo leert het systeem.

## Valkuilen
<!-- Voorbeeld: -->
<!-- - De kolom is `is_answer_ready`, NIET `answer_ready` -->
<!-- - Gebruik altijd soft deletes (deleted_at), nooit hard deletes -->
<!-- - Foreign keys MOETEN ON DELETE CASCADE hebben -->

## Naamconventies
- Tabellen: meervoud, snake_case (users, order_items)
- Kolommen: snake_case (created_at, is_active)
