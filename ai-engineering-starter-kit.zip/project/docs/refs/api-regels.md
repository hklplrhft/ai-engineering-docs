# API regels
# Voeg hier regels toe die Claude moet kennen bij API-werk.

## Conventies
<!-- Voorbeeld: -->
<!-- - Alle endpoints retourneren { data, error, meta } -->
<!-- - Gebruik altijd zod voor request validation -->
<!-- - Rate limiting: max 100 req/min per user -->

## Valkuilen
<!-- Voeg hier regels toe na elke API-gerelateerde fout -->
