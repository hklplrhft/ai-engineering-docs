# Build regels
# Voeg hier regels toe die Claude moet kennen bij build/deploy-werk.

## Valkuilen
<!-- Voorbeeld: -->
<!-- - Verwijder NOOIT bestanden uit public/js/ -- -->
<!--   deze worden automatisch gegenereerd door de build. -->
<!--   Check eerst: npm run build -->
