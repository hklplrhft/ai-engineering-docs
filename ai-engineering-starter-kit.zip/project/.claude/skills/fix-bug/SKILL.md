---
name: fix-bug
description: Fix een bug volgens de teamwerkwijze.
  Activeer bij bugs, errors, of onverwacht gedrag.
disable-model-invocation: true
---
Fix de volgende bug: $ARGUMENTS

## Verplichte stappen
1. Maak een branch: fix/[korte-naam]
2. Reproduceer de bug (draai de code, bekijk de error)
3. Analyseer de oorzaak (niet het symptoom)
4. Schrijf EERST een test die de bug reproduceert (test moet falen)
5. Fix de bug (test moet slagen)
6. Draai alle tests om te checken dat niets anders breekt
7. Voeg een regel toe aan docs/refs/ als dit een terugkerende fout is
8. Commit en open een draft PR

## Regels
- Fix de root cause, niet het symptoom
- Elke bugfix MOET een regressietest hebben
- Bij onduidelijke oorzaak: gebruik /plan eerst
