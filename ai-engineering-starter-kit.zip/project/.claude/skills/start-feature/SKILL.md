---
name: start-feature
description: Start een nieuwe feature volgens de teamwerkwijze.
  Activeer wanneer iemand een feature, component, of pagina wil bouwen.
disable-model-invocation: true
---
Start een nieuwe feature: $ARGUMENTS

## Verplichte stappen
1. Maak een nieuwe branch: feature/[korte-naam]
2. Ga in Plan Mode en analyseer wat nodig is
3. Presenteer het plan en wacht op goedkeuring
4. Na goedkeuring: implementeer stap voor stap
5. Schrijf tests voor elke nieuwe functie
6. Draai alle tests en fix fouten
7. Commit met een beschrijvende message
8. Open een draft PR met samenvatting

## Regels
- Wijzig NOOIT bestanden buiten de scope van de feature
- Bij twijfel: vraag, implementeer niet
- Elke publieke functie krijgt minimaal 1 test
