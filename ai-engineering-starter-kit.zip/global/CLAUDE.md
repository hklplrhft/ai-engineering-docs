# Globale regels -- ~/.claude/CLAUDE.md
# Kopieer dit bestand naar ~/.claude/CLAUDE.md
# Geldt voor AL je projecten.

## Werkwijze
- Werk ALTIJD op een branch, nooit direct op main
- Gebruik /plan bij taken die meer dan 1 bestand raken
- Commit na elke voltooide taak met een beschrijvende message
- Herinner me aan /clear bij wisseling van onderwerp
- Herinner me aan /compact bij lange sessies
- Geef bij elke implementatie verificatiecriteria mee (tests)

## Veiligheid
- Commit NOOIT .env, API keys, of wachtwoorden
- Vraag bevestiging voor: rm -rf, git push --force, drop table
- Review shell-commando's op veiligheid

## Stijl
- Comments in het Nederlands
- Code in het Engels
- Wees beknopt in uitleg, gedetailleerd in code
